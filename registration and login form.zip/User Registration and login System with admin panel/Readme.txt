How to run the User Registration & Login and User Management System With admin panel Project

1. Download the  zip file

2. Extract the file and copy loginsystem folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name loginsystem

6. Import loginsystem.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/loginsystem (frontend)

8. For admin Panel http://localhost/loginsystem/admin

Credential for admin panel :

Username: admin
Password: Test @123

Credential for user panel : 

Username: demouser@gmail.com 
Password : Test@123

For more details visit this url https://phpgurukul.com/user-registration-login-and-user-management-system-with-admin-panel/

You can also drop a mail at phpgurukulofficial@gmail.com 